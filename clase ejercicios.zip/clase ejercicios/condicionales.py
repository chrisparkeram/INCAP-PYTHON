#ejemplo
#cargaremos la edad en una variable
Edad=int(input("Ingrese una edad: "))
#Evaluamos el contenido de la variable edad
if Edad >= 18:
    #print(f"{Edad} pertenece a un adulto..")
    print((Edad), "esta es la edad")
else:
    print("no es mayor de edad...")