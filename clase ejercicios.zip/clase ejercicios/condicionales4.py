#Programa IF anidados
#Mostramos mensaje de inicio
#aqui combinamos if con conectores logicos
print("Ingrese una nota")
Nota = float(input("Digite la definitiva"))
if Nota>0 and Nota<3.0:#si nota es mayor a 0 y nota menor a 3 haga lo sigte
    print("Reprobó")
else:#de lo contrario
    if Nota>=3.0 and Nota<4.0:#si nota es mayor o igual a 3 y menor a 4
        print("Aprobó")
    else:
        if Nota>=4.0 and Nota<4.5:
            print("Aprobó Bien")
        else:
            if Nota>=4.5 and Nota<=5.0:
                print("Aprobó Excelente")
            else:
                print("Valor Inválido")