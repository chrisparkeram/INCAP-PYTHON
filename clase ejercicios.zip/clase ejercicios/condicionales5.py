"""Esta estructura, repetirá cíclicamente las sentencias que estén bajo su influencia, mientras la
evaluación de la condición sea verdad, cuando ésta, cambie a falso, el ciclo terminará y el
programa continuará línea a línea. Ejemplo:"""
#El siguiente programa, escribirá los valores de 0 a 20
#Inicializamos una variable en 0
Contador = 0
# Realizamos la comprobación de la condición
while Contador<21:
#Imprimimos el valor de la variable
    print(f"Iteración Número: {Contador}")
#Incrementamos el valor variable
    Contador+=1 