import sqlite3

conn = sqlite3.connect('Copamerica.DB')
cursor = conn.cursor()

try:
    cursor.execute('''CREATE TABLE America
                (id INTEGER PRIMARY KEY, Equipo TEXT, Jugador TEXT, posicion TEXT, edad INTEGER)''')
    conn.commit()
    print("Tabla de Libertadores creada correctamente.")
except sqlite3.Error as e:
    print("Error al crear la tabla:", e)

# Ejercicio 2: Insertar datos
America = [
    ('Colombia', 'Falcao', 'DC', 37),
    ('Colombia', 'James', 'DC', 34),
    ('Brasil', 'Neymar', "MC", 36),
    ('Brasil', 'Firmino', "MC", 36),
    ('Argentina', ' Sergio Romero', 'PO', 35),
    ('Argentina', 'Lionel Messi', 'DC', 33),
    ('Uruguay', 'Vinicius JR', 'DC', 25),
    ('Uruguay', 'Darwin nuñez', 'DF', 30),
    ('Uruguay', 'Edinson Cavani', 'DF', 32),
    ('Peru', 'Paolo guerrero', 'DC', 35),
    ('Peru', 'Luis Advincula', 'DF', 32),
    ('Peru', 'Juan Ortiz', 'DF', 24),
    ('Chile', 'Arturo Vidal', 'MC', 24),
    ('Chile', 'German Suazo', 'DF', 24)
]

try:
    cursor.executemany('INSERT INTO America (Equipo, Jugador, posicion, edad) VALUES (?, ?, ?, ?)', America)
    conn.commit()
    print("Datos insertados correctamente.")
except sqlite3.Error as e:
    print("Error al insertar datos:", e)

# Ejercicio 3: Consultar datos
try:
    cursor.execute('SELECT * FROM America WHERE edad > 30')
    resultado = cursor.fetchall()
    print("Jugadores que tengan una edad mayor a 30")
    for producto in resultado:
        print(producto)
except sqlite3.Error as e:
    print("Error al consultar datos:", e)

# Ejercicio 4: Actualizar datos
try:
    cursor.execute("UPDATE America SET posicion = 'MC'  WHERE edad = 30")
    conn.commit()
    print("Jugador actualiza posicion de DF a MC")
except sqlite3.Error as e:
    print("Error al actualizar datos:", e)

# Ejercicio 5: Eliminar datos
try:
    cursor.execute('DELETE FROM America WHERE id = 2')
    conn.commit()
    print("Jugador con id 2 eliminado de la base de datos.")
except sqlite3.Error as e:
    print("Error al eliminar datos:", e)

# Cerrar conexión
conn.close()