import sqlite3

# Crear conexión
conn = sqlite3.connect('copaAMERICAA.db')
cursor = conn.cursor()

# Crear tabla si no existe
cursor.execute('''CREATE TABLE IF NOT EXISTS equipos
               (nombre_equipo TEXT, jugador TEXT PRIMARY KEY, edad INTEGER, posicion TEXT, suplente TEXT )''')
conn.commit()

# Datos de los equipos y jugadores
equipos = [
    ("Argentina", [
        ("Lionel Messi", 34, "Delantero", "Ángel Di María"),
        ("Sergio Agüero", 33, "Delantero", "Julian Alvarez"),
        ("Nicolas Otamendi", 33, "Defensa", "Lucas Martínez Quarta"),
        ("Emiliano Martínez", 29, "Portero", "Franco Armani")
    ]),
    ("Brasil", [
        ("Neymar Jr", 30, "Delantero", "Roberto Firmino"),
        ("Casemiro", 30, "Centrocampista", "Arthur"),
        ("Thiago Silva", 38, "Defensa", "Cafu"),
        ("Alisson Becker", 29, "Portero", "Ederson")
    ]),

    ("Uruguay1", [
        ("Luis Suárez", 35, "Delantero", "Darwin Nuñez"),
        ("Edinson Cavani", 36, "Delantero", "Diego Forlan"),
        ("José María Giménez", 27, "Defensa", "Sebastián Coates"),
        ("Fernando Muslera", 36, "Portero", "Martín Campaña")
    ]),
    ("Uruguay2", [
        ("Luis Suárez", 35, "Delantero", "Maxi Gómez"),
        ("Edinson Cavani", 36, "Delantero", "Diego Godín"),
        ("José María Giménez", 27, "Defensa", "Sebastián Coates"),
        ("Fernando Muslera", 36, "Portero", "Martín Campaña")
    ]),
    # Agrega datos para los otros equipos de manera similar
]

# Insertar datos de los equipos y jugadores
for equipo, jugadores in equipos:
    for jugador in jugadores:
        cursor.execute('INSERT INTO equipos (nombre_equipo, jugador, edad, posicion, suplente) VALUES (?,?,?,?,?)', (equipo, jugador[0], jugador[1], jugador[2], jugador[3]))

conn.commit()

# Consultar datos
cursor.execute('SELECT * FROM equipos')
resultados = cursor.fetchall()
print("Jugadores de todos los equipos:")
for equipo in resultados:
    print(equipo)

# Cerrar conexión
conn.close()