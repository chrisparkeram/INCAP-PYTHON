valor_a = 5
#               0 1 2  3  4
valor_lista = [4,8,24,29,100]

print(valor_lista[0])