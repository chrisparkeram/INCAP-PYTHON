def mi_funcion(lambda_func):
    return lambda_func(2,4)


resultado= mi_funcion(lambda a, b: a + b)
print(resultado)