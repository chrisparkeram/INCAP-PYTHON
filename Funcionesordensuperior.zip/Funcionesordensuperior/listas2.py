# 0 1 2 3 4 5 6
lista_2 = ["yo","soy","un","estudiante","muy","bueno"]


print(lista_2)

lista_2.append("inteligente")

print(lista_2)

lista_2.pop()

print(lista_2)

lista_2.extend("yo")

print(lista_2)