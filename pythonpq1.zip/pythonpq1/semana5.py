#crea base de datos con su respectiva tabla
import sqlite3
conn = sqlite3.connect('tienda.db')
cursor = conn.cursor()
cursor.execute('''CREATE TABLE IF NOT EXISTS productos
                (id INTERGER PRIMARY KEY, nombre, TEXT, precio REAL, stock INTERGER)''')
conn.commit()

#insertar datos
productos = [
    ('producto A', 50.0, 100),
    ('producto B', 70.0, 80),
    ('producto C', 60.0, 120),
    ('producto D', 90.0, 60),
    ('producto E', 55.0, 120)
]

cursor.executemany('INSERT INTO productos (nombre, precio, stock) VALUES (?,?,?)', productos)
conn.commit()

#consultar los datos de la tabla
cursor.execute('SELECT * FROM productos WHERE precio > 50')
resultados = cursor.fetchall()
print("Productos con los precios superior a $50:")
for producto in resultados:
    print(producto)        
#Actualizar datos de la tabla
cursor.execute('UPDATE productos SET precio = 80.0 WHERE id = 1')
conn.commit()
print("Precio actualizado para el producto A.")


#Eliminar datos de la tabla
cursor.execute('DELETE FROM productos WHERE id = 2')
conn.commit()
print("Producto B eliminado de la base de datos productos")

#cerrar conexion
conn.close() 