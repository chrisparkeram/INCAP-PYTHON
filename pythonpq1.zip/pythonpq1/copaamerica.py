import sqlite3
conn = sqlite3.connect('equipos.db')
cursor = conn.cursor()
cursor.execute('''CREATE TABLE IF NOT EXISTS jugadores
                (jugador TEXT PRIMARY KEY, edad INTERGER, posicion REAL, suplente TEXT)''')
conn.commit()

jugadores = [
    ('falcao', 32, 'delantero', 'james'),
    ('quintero', 30,'delantero', 'bacca'),
    ('neymar', 30,'delantero', 'mbappe'),
    ('quintero', 30,'delantero', 'bacca'),
    
]

cursor.executemany('INSERT INTO jugadores (nombre, edad, posicion, suplente) VALUES (?,?,?,?)', jugadores)
conn.commit()
#consultar los datos de la tabla
cursor.execute('SELECT * FROM jugadores WHERE jugador > 30')
resultados = cursor.fetchall()
print("nombre del jugador :")
for jugador in resultados:
    print(jugador)        
#Actualizar datos de la tabla
cursor.execute('UPDATE jugadores SET edad = 26 WHERE id = jugador A1')
conn.commit()
print("Precio actualizado para el producto A.")


#Eliminar datos de la tabla
cursor.execute('DELETE FROM jugadores WHERE id = 2')
conn.commit()
print("Producto B eliminado de la base de datos productos")

#cerrar conexion
conn.close() 