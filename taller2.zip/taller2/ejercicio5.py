#Duplicar todos los elementos de una lista
# Define the list
numeros = [1, 2, 3, 4, 5]


duplicados = map(lambda x: x * 2, numeros)


duplicados = list(duplicados)


print("Los numeros duplicados son:", duplicados)