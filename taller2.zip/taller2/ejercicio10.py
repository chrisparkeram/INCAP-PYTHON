#Concatenar todas las cadenas de una lista en una sola cadena
from functools import reduce

# Definir la lista de cadenas
lista_cadenas = ["Clase", " ", "Python2", " ", "Incap"]

# Utilizar reduce y lambda para concatenar todas las cadenas
cadena_concatenada = reduce(lambda x, y: x + y, lista_cadenas)

print("Lista original:", lista_cadenas)
print("Cadena concatenada:", cadena_concatenada)
