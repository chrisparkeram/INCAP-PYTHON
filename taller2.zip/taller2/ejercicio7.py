#Filtrar números pares de una lista y luego calcular su suma
from functools import reduce

# Definir la lista de números
numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Filtrar números pares usando filter
numeros_pares = filter(lambda x: x % 2 == 0, numeros)

# Calcular la suma de los números pares usando reduce
suma_pares = reduce(lambda x, y: x + y, numeros_pares)

print("Números pares de la lista:", list(numeros_pares))
print("La suma de los números pares es:", suma_pares)
