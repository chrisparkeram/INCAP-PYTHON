#Multiplicación de todos los elementos de una lista
from functools import reduce
# Definir la lista
lista = [1, 2, 3, 4, 5]

producto_total = reduce(lambda x, y: x * y, lista)
print("Multiplicación de todos los elementos:", producto_total)