#Obtener el máximo elemento de una lista
from functools import reduce

lista = [1, 2, 3, 4, 5]
maximo_elemento = reduce(lambda x, y: x if x > y else y, lista)

print("Máximo elemento de la lista:", maximo_elemento)