from functools import reduce
# Define the list and the value
numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
valor = 5

# Use filter to filter the elements greater than the value
filtered_numbers = filter(lambda x: x > valor, numeros)

# Use reduce to count the number of elements
cuenta = reduce(lambda x, y: x + 1, filtered_numbers, 0)

# Print the result
print("The number of elements greater than", valor, "is:", cuenta)