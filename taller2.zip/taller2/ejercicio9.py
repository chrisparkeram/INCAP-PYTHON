#Elevar al cuadrado todos los elementos de una lista
# Definir la lista de números
lista_numeros = [1, 2, 3, 4, 5]

# Usar map y lambda para elevar al cuadrado todos los elementos de la lista
lista_cuadrados = list(map(lambda x: x ** 2, lista_numeros))

print("Lista original:", lista_numeros)
print("Lista con los elementos elevados al cuadrado:", lista_cuadrados)
