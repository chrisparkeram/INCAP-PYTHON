
#Suma de todos los elementos de una lista:

from functools import reduce

# Definir la lista
lista = [1, 2, 3, 4, 5]

# Usar reduce y lambda para sumar los elementos de la lista
resultado = reduce(lambda x, y: x + y, lista)

print("La suma de todos los elementos de la lista es:", resultado)
