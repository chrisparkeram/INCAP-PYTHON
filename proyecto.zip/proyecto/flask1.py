from flask import Flask, render_template

# Creamos una instancia de Flask
app = Flask(__name__)

# Definimos una ruta para la página principal
@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
