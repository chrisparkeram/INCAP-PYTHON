Edad = int(input("Ingrese su edad: "))

if Edad < 4:
    precio = 0
elif Edad <= 18:
    precio = 5
else:
    precio = 10

print("El precio de la entrada es: " + str(precio) + "€")