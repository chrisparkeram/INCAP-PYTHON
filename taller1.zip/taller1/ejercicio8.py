num = int(input("Ingrese un numero: "))

for i in range(1, 16):
    resultado = num * i
    print(num, "x", i, "=", resultado)