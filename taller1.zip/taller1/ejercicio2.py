password = "password"

user_input = input("Ingrese su contraseña: ")

if user_input.lower() == password.lower():
    print("Contraseña correcta")
else:
    print("Contraseña incorrecta")