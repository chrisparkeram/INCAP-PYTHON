Edad= int(input("Ingrese su edad: "))

for i in range(1, Edad + 1):
    print(i)