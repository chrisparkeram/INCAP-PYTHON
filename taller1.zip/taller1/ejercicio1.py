Edad = int(input("Ingrese su edad: "))

if Edad >= 18:
    print("Eres mayor de edad.")
else:
    print("Tu eres menor de edad.")