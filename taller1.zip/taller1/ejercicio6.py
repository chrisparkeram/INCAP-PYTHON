palabra = input("Ingresa una palabra: ")

for i in range(10):
    print(palabra)