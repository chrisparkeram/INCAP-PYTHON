print("Bienvenido a Bella Napoli pizzeria!")
print("Nuestra oferta vegetariana y no vegetariana.")

pizza_type = input("Quieres una pizza vegetariana o no-vegetaria? \n (vegetariana/no vegetariana) ")

if pizza_type == "vegetariana":
    print("Disponible vegetarian ingredients: Pimiento, Tofu")
    ingrediente = input("Escoge un ingrediente: ")
    print("Tu pizza vegetariana con " + ingrediente + " Pronto estara listo")
else:
    print("Disponible no-vegetarian ingredients: Peperoni, Jamón, Salmón")
    ingrediente = input("Escoge un ingrediente: ")
    print("Tu pizza no-vegetariana con " + ingrediente + " Pronto estara listo")

print("Todas nuestras pizzas vienen con mozzarella y tomate.")
print("GRacias por escogernos Bella Napoli!")