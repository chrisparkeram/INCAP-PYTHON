Edad = int(input("Ingrese su edad: "))
ingreso = float(input("Ingrese sus ingresos mensuales: "))

if Edad >= 16 and ingreso >= 1000:
    print("Ud debe pagar impuestos.")
else:
    print("Ud no paga impuestos.")